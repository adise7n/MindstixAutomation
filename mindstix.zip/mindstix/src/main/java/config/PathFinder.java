package config;

import java.io.File;

public class PathFinder {
	
	public static void main(String ar[]){
		
		
//		String path = System.getProperty("mindstix\\src\\main\\java\\dataEngine\\DataEngine.xlsx");
//		System.out.println(" Path "+path);
		
		
		File f = new File("src\\main\\java\\dataEngine\\DataEngine.xlsx");		
		System.out.println("File "+f.getPath());
	}

}
